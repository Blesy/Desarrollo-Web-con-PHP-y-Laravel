<?php 
    echo "<img src='logo.png' width='500px'/>";
    echo "<p><a href='index.php'>Inicio</a></p>";
    echo "<hr/>"
?>